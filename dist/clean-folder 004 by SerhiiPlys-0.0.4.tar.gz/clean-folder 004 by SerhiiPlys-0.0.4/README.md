# Project Name

This is a styding project on GoiT_Python5
This app clean and reclean folder cotains garbage
You can use command line(prefer) or simle - input path via keyboard

## Installation

The installation process as usuial using pip

## Usage

Usage is very simple - install and use))))

## Contributing



## History

Version 0.0.4

## Credits

Free for now

## License

It uses MIT license